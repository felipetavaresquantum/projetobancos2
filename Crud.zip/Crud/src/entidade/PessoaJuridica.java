
package entidade;


/**
 *
 * @author denilson
 */
public class PessoaJuridica extends Pessoa{

    private Integer idPessoaJuridica;
    private String cnpj;
    private String dataAbertura;
    private String inscricaoEstadual;

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }
   

    public PessoaJuridica() {
    }

    public PessoaJuridica(Integer idPessoaJuridica) {
        this.idPessoaJuridica = idPessoaJuridica;
    }

    public PessoaJuridica(Integer idPessoaJuridica, String cnpj, String dataAbertura) {
        this.idPessoaJuridica = idPessoaJuridica;
        this.cnpj = cnpj;
        this.dataAbertura = dataAbertura;
    }

    public Integer getIdPessoaJuridica() {
        return idPessoaJuridica;
    }

    public void setIdPessoaJuridica(Integer idPessoaJuridica) {
        this.idPessoaJuridica = idPessoaJuridica;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

   

}
